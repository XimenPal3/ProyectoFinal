﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WFArbolBinario.Estructuras_de_datos.TablaHash2
{
    public class ListaHash
    {
        public NodoHash primero;

        public ListaHash()
        {
            primero = null;
        }

        public void InsertarCabezaLista2(string clave, object registro)
        {
            NodoHash nuevo;
            nuevo = new NodoHash(clave, registro);
            nuevo.Enlace = primero;
            primero = nuevo;
        }

        public object Buscar2(string clave)
        {
            NodoHash indice;
            for (indice = primero; indice != null; indice = indice.Enlace)
            {
                if (clave.Equals(indice.Clave))
                {
                    return indice.Dato;
                }
            }

            return null;
        }

        public void Eliminar2(string clave)
        {
            NodoHash actual, anterior;
            bool encontrado;

            actual = primero;
            anterior = null;
            encontrado = false;

            while ((actual != null) && (!encontrado))
            {
                encontrado = (clave.Equals(actual.Clave));

                if (!encontrado)
                {
                    anterior = actual;
                    actual = actual.Enlace;
                }
            }

            if (actual != null)
            {
                if (anterior == null)
                    primero = actual.Enlace;
                else
                    anterior.Enlace = actual.Enlace;
            }
        }

        public void ActualizarNodo2(string clave, object nuevoRegistro)
        {
            NodoHash actual = primero;
            bool encontrado = false;

            // Buscar el nodo con la clave dada
            while (actual != null && !encontrado)
            {
                if (actual.Clave.Equals(clave))
                {
                    encontrado = true;
                    actual.Dato = nuevoRegistro; // Actualizar el dato del nodo encontrado
                }
                else
                {
                    actual = actual.Enlace;
                }
            }

            if (!encontrado)
            {
                Console.WriteLine("Registro no encontrado.");
            }
        }
    }
}
