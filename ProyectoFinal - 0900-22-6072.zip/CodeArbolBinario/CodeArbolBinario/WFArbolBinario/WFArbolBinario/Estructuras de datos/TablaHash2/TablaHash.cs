﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WFArbolBinario.Estructuras_de_datos.TablaHash2;

namespace WFArbolBinario.Estructuras_de_datos
{
    public class TablaHash
    {
        public static readonly int M = 400;

        ListaHash[] TablaHashGen;
        int Posicion;

        public TablaHash()
        {
            TablaHashGen = new ListaHash[M];
        }

        public int DispersionMod(string clave)
        {
            int suma = 0;
            foreach (char c in clave)
            {
                suma += (int)c;
            }
            return suma % M;

        }

        public void Insertar(string clave, object Dato)
        {
            Posicion = DispersionMod(clave);

            if (TablaHashGen[Posicion] == null)
                TablaHashGen[Posicion] = new ListaHash();
            TablaHashGen[Posicion].InsertarCabezaLista2(clave, Dato);
        }

        public void Eliminar(string clave)
        {
            Posicion = DispersionMod(clave);
            TablaHashGen[Posicion].Eliminar2(clave);
        }

        public void Actualizar(string clave, object Dato)
        {
            Posicion = DispersionMod(clave);
            TablaHashGen[Posicion].ActualizarNodo2(clave, Dato);
        }

        public object Consultar(string clave)
        {
            Posicion = DispersionMod(clave);
            return TablaHashGen[Posicion].Buscar2(clave);
        }
    }
}
