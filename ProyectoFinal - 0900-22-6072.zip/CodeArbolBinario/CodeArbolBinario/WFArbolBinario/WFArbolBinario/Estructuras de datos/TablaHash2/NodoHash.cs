﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WFArbolBinario.Estructuras_de_datos.TablaHash2
{
    public class NodoHash
    {
        public string Clave;
        public Object Dato;
        public NodoHash Enlace;

        public NodoHash(string clave, Object dato)
        {
            Clave = clave;
            Dato = dato;
            Enlace = null;
        }
    }
}
