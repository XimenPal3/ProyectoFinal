﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WFArbolBinario.ListaEnlazada
{
    public class Lista
    {
        public NodoLista primero;

        public Lista()
        {
            primero = null;
        }
        public void InsertarCabezaLista(object vDato)
        {
            NodoLista nuevo;
            nuevo = new NodoLista(vDato);
            nuevo.Enlace = primero;
            primero = nuevo;
        }

        public Lista insertarUltimo(NodoLista ultimo, object entrada)
        {
            ultimo.Enlace = new NodoLista(entrada);
            ultimo = ultimo.Enlace;
            return this;
        }

        public Lista insertarLista1(NodoLista anterior, object entrada)
        {
            NodoLista nuevo;
            nuevo = new NodoLista(entrada);
            nuevo.Enlace = anterior.Enlace;
            anterior.Enlace = nuevo;
            return this;
        }

        public NodoLista buscarNodoLista(Jugadores destino)
        {
            NodoLista indice;
            for (indice = primero; indice != null; indice = indice.Enlace)
            {
                Jugadores jugador = (Jugadores)indice.Dato;
                if (destino.nombre.Equals(jugador.nombre))
                {
                    return indice;
                }
            }

            return null;
        }


        public void eliminar(object entrada)
        {
            NodoLista actual, anterior;
            bool encontrado = false;

            actual = primero;
            anterior = null;

            // Buscar el nodo que contiene el dato a eliminar
            while (actual != null && !encontrado)
            {
                if (actual.Dato.Equals(entrada))
                {
                    encontrado = true;
                }
                else
                {
                    anterior = actual;
                    actual = actual.Enlace;
                }
            }

            // Si se encontró el nodo, eliminarlo
            if (encontrado)
            {
                // Si es el primer nodo de la lista
                if (anterior == null)
                {
                    primero = actual.Enlace;
                }
                else
                {
                    anterior.Enlace = actual.Enlace;
                }
            }
            else
            {
                Console.WriteLine("El dato a eliminar no se encontró en la lista.");
            }
        }

        public void actualizar(Jugadores datoAntiguo, Jugadores datoNuevo)
        {
            NodoLista nodo = buscarNodoLista(datoAntiguo);
            if (nodo != null)
            {
                nodo.Dato = datoNuevo;
            }
            else
            {
                Console.WriteLine("El dato a actualizar no se encontró en la lista.");
            }
        }

    }
}
