﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WFArbolBinario.ListaEnlazada
{
    public class NodoLista
    {
        public object Dato;
        public NodoLista Enlace;

        public NodoLista(object vDato)
        {
            Dato = vDato;
            Enlace = null;
        }
    }
}
