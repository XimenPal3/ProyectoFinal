﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Nombre: Ximena Lissett Palencia Palacios
//Carnet: 0900-22-6072

namespace WFArbolBinario
{
    public partial class Form2 : Form
    {
        ArbolAVL ArbolAVL = new ArbolAVL();
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //Inserción de datos del archivo "PremierLeague18_19_Equipos.csv"
            int counter = 0;
            string line;

            System.IO.StreamReader file =
                new System.IO.StreamReader("C:\\Users\\ximen\\OneDrive\\Documents\\PremierLeague18_19_Equipos.csv");
            
            Char delimiter = ',';
            //Se delimita que la separación de los datos es con ","

            while ((line = file.ReadLine()) != null)
            {
                String[] substrings = line.Split(delimiter);
                Equipos objetoequipos = new Equipos(substrings[0], substrings[1], substrings[2], substrings[3],
                    Convert.ToInt32(substrings[4]), Convert.ToInt32(substrings[5]), Convert.ToInt32(substrings[6]),
                    Convert.ToInt32(substrings[7]), Convert.ToInt32(substrings[8]));

                ArbolAVL.insertar(objetoequipos);
            }
            file.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Se busca y lee el dato ingresasdo en el "textBox10.Text"
            Equipos valorx;
            Equipos valorB = new Equipos("", textBox10.Text, "", "", 0, 0, 0, 0, 0);
            valorx = (Equipos)ArbolAVL.buscar(valorB).valorNodo();

            //Muestra los datos encontrados en los textBox correspondientes
            textBox1.Text = valorx.nombreequipo;
            textBox2.Text = valorx.nombrecom;
            textBox3.Text = valorx.temporada;
            textBox4.Text = valorx.pais;
            textBox5.Text = Convert.ToString(valorx.partjugs);
            textBox6.Text = Convert.ToString(valorx.partjugscas);
            textBox7.Text = Convert.ToString(valorx.partjugsfuer);
            textBox8.Text = Convert.ToString(valorx.partsusp);
            textBox9.Text = Convert.ToString(valorx.partgan);

            textBox10.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Se busca y lee el dato ingresasdo en el "textBox10.Text"
            Equipos valorx;
            Equipos valorB = new Equipos("", textBox10.Text, "", "", 0, 0, 0, 0, 0);
            valorx = (Equipos)ArbolAVL.buscar(valorB).valorNodo();
            //Los datos al ser encontrados, se eliminan.
            ArbolAVL.eliminar(valorx);
            MessageBox.Show("El equipo: "+valorx.nombreequipo+" fué eliminado del torneo.");


            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Equipos valorB = new Equipos(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, 
                Convert.ToInt32(textBox5.Text), Convert.ToInt32(textBox6.Text), Convert.ToInt32(textBox7.Text),
                Convert.ToInt32(textBox8.Text), Convert.ToInt32(textBox9.Text));

            ArbolAVL.insertar(valorB);
            MessageBox.Show("El equipo: " + valorB.nombreequipo + " fué ingresado al torneo.");

            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();

            Form1 formulario1 = new Form1();
            formulario1.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
        }
    }
}
