﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Nombre: Ximena Lissett Palencia Palacios
//Carnet: 0900-22-6072

namespace WFArbolBinario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 formulario2 = new Form2();
            // Mostrar Formulario2
            formulario2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 formulario3 = new Form3();
            // Mostrar Formulario3
            formulario3.Show();            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 formulario4 = new Form4();
            //Mostrar Formulario 4
            formulario4.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form5 formulario5 = new Form5();
            //Mostrar Formulario 5
            formulario5.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
