﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WFArbolBinario.Clases
{
    public class Partidos
    {
        public string marctemp;
        public string fecha;
        public string estado;
        public int pubpres;
        public string eqlocal;
        public string eqvisit;
        public string arbitro;
        public int semjueg;
        public decimal ppgprevlocal;
        public decimal ppgprevvisit;
        public decimal ppglocal;
        public decimal ppgvisit;

        public Partidos(string vmarctemp, string vfecha, string vestado, int vpubpres, 
            string veqlocal, string veqvisit, string varbitro, int vsemjueg, decimal vppgprevlocal,
            decimal vppgprevvisit, decimal vppglocal, decimal vppgvisit)
        {
            marctemp = vmarctemp;
            fecha = vfecha;
            estado = vestado;
            pubpres = vpubpres;
            eqlocal = veqlocal;
            eqvisit = veqvisit;
            arbitro = varbitro;
            semjueg = vsemjueg;
            ppgprevlocal = vppgprevlocal;
            ppgprevvisit = vppgprevvisit;
            ppglocal = vppglocal;
            ppgvisit = vppgvisit;
        }

        public Partidos()
        {
            marctemp = "";
            fecha = "";
            estado = "";
            pubpres = 0;
            eqlocal = "";
            eqvisit = "";
            arbitro = "";
            semjueg = 0;
            ppgprevlocal = 0;
            ppgprevvisit = 0;
            ppglocal = 0;
            ppgvisit = 0;
        }
    }
}
