﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WFArbolBinario
{
    public class Jugadores
    {
        public string nombre;
        public int edad;
        public int cump;
        public string cumpGMT;
        public string liga;
        public string temp;
        public string posi;
        public string club;
        public int minjug;
        public int minjugcas;
        public int minjugfuer;
        public string nacion;

        public Jugadores(string vnombre, int vedad, int vcump, string vcumpgmt, string vliga, string vtemp, string vposi,
            string vclub, int vminjug, int vminjugcas, int vminjugfuer, string vnacion)
        {
            nombre = vnombre;
            edad = vedad;
            cump = vcump;
            cumpGMT = vcumpgmt;
            liga = vliga;
            temp = vtemp;
            posi = vposi;
            club = vclub;
            minjug = vminjug;
            minjugcas = vminjugcas;
            minjugfuer = vminjugfuer;
            nacion = vnacion;
        }

        public Jugadores()
        {
            nombre = "";
            edad = 0;
            cump = 0;
            cumpGMT = "";
            liga = "";
            temp = "";
            posi = "";
            club = "";
            minjug = 0;
            minjugcas = 0;
            minjugfuer = 0;
            nacion = "";
        }
    }
}
