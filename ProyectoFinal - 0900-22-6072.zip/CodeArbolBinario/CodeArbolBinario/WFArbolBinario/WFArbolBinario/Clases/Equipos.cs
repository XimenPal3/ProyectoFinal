﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace WFArbolBinario
{
    public class Equipos : Comparador
    {
        public string nombreequipo { get; set; }
        public string nombrecom { get; set; }
        public string temporada { get; set; }
        public string pais { get; set; }
        public int partjugs { get; set; }
        public int partjugscas { get; set; }
        public int partjugsfuer { get; set; }
        public int partsusp { get; set; }
        public int partgan { get; set; }

        public Equipos(string nombreequipo, string nombrecom, string temporada, string pais, int partjugs, int partjugscas, int partjugsfuer, int partsusp, int partgan)
        {
            this.nombreequipo = nombreequipo;
            this.nombrecom = nombrecom;
            this.temporada = temporada;
            this.pais = pais;
            this.partjugs = partjugs;
            this.partjugscas = partjugscas;
            this.partjugsfuer = partjugsfuer;
            this.partsusp = partsusp;
            this.partgan = partgan;
        }

        bool Comparador.igualQue(Object op2)
        {
            Equipos p2 = (Equipos)op2;
            return nombrecom == p2.nombrecom;
        }

        bool Comparador.menorQue(Object op2)
        {
            Equipos p2 = (Equipos)op2;
            if (nombrecom.CompareTo(p2.nombrecom) < 0)
                return true;
            else
                return false;
        }

        bool Comparador.menorIgualQue(Object op2)
        {
            Equipos p2 = (Equipos)op2;
            if (nombrecom.CompareTo(p2.nombrecom) <= 0)
                return true;
            else
                return false;
        }

        bool Comparador.mayorQue(Object op2)
        {
            Equipos p2 = (Equipos)op2;
            if (nombrecom.CompareTo(p2.nombrecom) > 0)
                return true;
            else
                return false;
        }

        bool Comparador.mayorIgualQue(Object op2)
        {
            Equipos p2 = (Equipos)op2;
            if (nombrecom.CompareTo(p2.nombrecom) >= 0)
                return true;
            else
                return false;
        }

        public override string ToString()
        {
            return "(" +nombreequipo+" - "+nombrecom+" _ "+temporada+ " _ " 
                +pais+ " _ "+partjugs+" _ "+partjugscas+" _ "+partjugsfuer+ " _ " +partsusp+ " _ "
                +partgan+")";
        }
    }
}
