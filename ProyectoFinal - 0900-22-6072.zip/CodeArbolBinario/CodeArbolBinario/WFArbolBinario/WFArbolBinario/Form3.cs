﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFArbolBinario.Clases;
using WFArbolBinario.Estructuras_de_datos;

//Nombre: Ximena Lissett Palencia Palacios
//Carnet: 0900-22-6072

namespace WFArbolBinario
{
    public partial class Form3 : Form
    {
        TablaHash mitabla = new TablaHash();

        public Form3()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();

            Form1 formulario1 = new Form1();
            formulario1.Show();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            //Inserción de datos del archivo "PremierLeague18_19_Partidos.csv"
            int counter = 0;
            string line;

            System.IO.StreamReader file =
                new System.IO.StreamReader("C:\\Users\\ximen\\OneDrive\\Documents\\PremierLeague18_19_Partidos.csv");

            Char delimiter = ',';

            while ((line = file.ReadLine()) != null)
            {
                String[] substrings = line.Split(delimiter);
                Partidos objetopartidos = new Partidos(substrings[0], substrings[1], substrings[2],
                    Convert.ToInt32(substrings[3]), substrings[4], substrings[5], substrings[6], Convert.ToInt32(substrings[7]), 
                    Convert.ToDecimal(substrings[8]), Convert.ToDecimal(substrings[9]), Convert.ToDecimal(substrings[10]), 
                    Convert.ToDecimal(substrings[11]));

                //Se ingresan los datos en la tabla Hash
                mitabla.Insertar(substrings[1], objetopartidos);
            }
            file.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Se busca en la tabla los datos del textBox13.Text
            string fecha = textBox13.Text;
            object encontrado = mitabla.Consultar(fecha);

            if (encontrado != null && encontrado is Partidos)
            {
                Partidos partidos = (Partidos)encontrado;

                //Se muestran los datos en los correspondientes textBox
                textBox1.Text = partidos.marctemp;
                textBox2.Text = partidos.fecha;
                textBox3.Text = partidos.estado;
                textBox4.Text = Convert.ToString(partidos.pubpres);
                textBox5.Text = partidos.eqlocal;
                textBox6.Text = partidos.eqvisit;
                textBox7.Text = partidos.arbitro;
                textBox8.Text = Convert.ToString(partidos.semjueg);
                textBox9.Text = Convert.ToString(partidos.ppgprevlocal);
                textBox10.Text = Convert.ToString(partidos.ppgprevvisit);
                textBox11.Text = Convert.ToString(partidos.ppglocal);
                textBox12.Text = Convert.ToString(partidos.ppgvisit);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            //Se eliminan los datos al buscar el textBox13
            string fecha = textBox13.Text;
            mitabla.Eliminar(fecha);
            MessageBox.Show("El partido ha sido eliminado.");
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string marcatiemp = textBox1.Text;
            string fecha = textBox2.Text;
            string estado = textBox3.Text;

            int publico;
            if (!int.TryParse(textBox4.Text, out publico))
            {
                MessageBox.Show("La cantidad del público debe ser un número entero válido.");
                return;
            }

            string nomblocal = textBox5.Text;
            string nombvisit = textBox6.Text;
            string arbitro = textBox7.Text;

            int semjueg;
            if (!int.TryParse(textBox8.Text, out semjueg))
            {
                MessageBox.Show("La semana del juego debe ser un número entero válido.");
                return;
            }

            decimal ppglocprev;
            if (!decimal.TryParse(textBox9.Text, out ppglocprev))
            {
                MessageBox.Show("La PPG previo al partido local debe ser un número decimal válido.");
                return;
            }

            decimal ppgvisitprev;
            if (!decimal.TryParse(textBox10.Text, out ppgvisitprev))
            {
                MessageBox.Show("La PPG previo al partido visitado debe ser un número decimal válido.");
                return;
            }

            decimal ppglocal;
            if (!decimal.TryParse(textBox11.Text, out ppglocal))
            {
                MessageBox.Show("La PPG partido local debe ser un número decimal válido.");
                return;
            }

            decimal ppgvisit;
            if (!decimal.TryParse(textBox12.Text, out ppgvisit))
            {
                MessageBox.Show("La PPG partido visitante debe ser un número decimal válido.");
                return;
            }

            Partidos mispartidos = new Partidos(marcatiemp, fecha, estado, publico, nomblocal, nombvisit,
                arbitro, semjueg, ppglocprev, ppgvisitprev, ppglocal, ppgvisit);

            mitabla.Actualizar(textBox13.Text, mispartidos);

            MessageBox.Show("El atleta ha sido actualizado.");

            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
        }
    }
}
