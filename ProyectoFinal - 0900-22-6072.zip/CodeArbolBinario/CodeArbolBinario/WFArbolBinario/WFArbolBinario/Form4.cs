﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFArbolBinario.ListaEnlazada;

//Nombre: Ximena Lissett Palencia Palacios
//Carnet: 0900-22-6072

namespace WFArbolBinario
{
    public partial class Form4 : Form
    {
        Lista miLista;

        public Form4()
        {
            InitializeComponent();
            miLista = new Lista();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            int counter = 0;
            string line;

            System.IO.StreamReader file =
                new System.IO.StreamReader("C:\\Users\\ximen\\OneDrive\\Documents\\PremierLeague18_19_Jugadores.csv");

            Char delimiter = ',';

            while ((line = file.ReadLine()) != null)
            {
                String[] substrings = line.Split(delimiter);
                Jugadores objetoequipos = new Jugadores(substrings[0], Convert.ToInt32(substrings[1]), Convert.ToInt32(substrings[2]),
                    substrings[3], substrings[4], substrings[5], substrings[6], substrings[7], Convert.ToInt32(substrings[8]),
                    Convert.ToInt32(substrings[9]), Convert.ToInt32(substrings[10]), substrings[11]);

                miLista.InsertarCabezaLista(objetoequipos);
            }
            file.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();

            Form1 formulario1 = new Form1();
            formulario1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nombreJugador = textBox13.Text;
            Jugadores jugadorBuscado = new Jugadores(nombreJugador, 0, 0, "", "", "", "", "", 0, 0, 0, "");
            NodoLista nodo = miLista.buscarNodoLista(jugadorBuscado);

            if (nodo != null)
            {
                // Obtener el jugador del nodo encontrado
                Jugadores jugadorEncontrado = (Jugadores)nodo.Dato;

                // Mostrar los datos del jugador encontrado en los campos de texto
                textBox1.Text = jugadorEncontrado.nombre;
                textBox2.Text = Convert.ToString(jugadorEncontrado.edad);
                textBox3.Text = Convert.ToString(jugadorEncontrado.cump);
                textBox4.Text = Convert.ToString(jugadorEncontrado.cumpGMT);
                textBox5.Text = jugadorEncontrado.liga;
                textBox6.Text = jugadorEncontrado.temp;
                textBox7.Text = jugadorEncontrado.posi;
                textBox8.Text = jugadorEncontrado.club;
                textBox9.Text = Convert.ToString(jugadorEncontrado.minjug);
                textBox10.Text = Convert.ToString(jugadorEncontrado.minjugcas);
                textBox11.Text = Convert.ToString(jugadorEncontrado.minjugfuer);
                textBox12.Text = jugadorEncontrado.nacion;
            }
            else
            {
                MessageBox.Show("El jugador no se encontró en la lista.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string nombreJugador = textBox13.Text;
            Jugadores jugadorBuscado = new Jugadores(nombreJugador, 0, 0, "", "", "", "", "", 0, 0, 0, "");
            NodoLista nodo = miLista.buscarNodoLista(jugadorBuscado);

            if (nodo != null)
            {
                miLista.eliminar(nodo);

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();

                MessageBox.Show("Jugador eliminado correctamente.");
            }
            else
            {
                MessageBox.Show("El jugador no se encontró en la lista.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string nombreJugadorAntiguo = textBox13.Text;
            Jugadores jugadorAntiguo = new Jugadores(nombreJugadorAntiguo, 0, 0, "", "", "", "", "", 0, 0, 0, "");
            NodoLista nodo = miLista.buscarNodoLista(jugadorAntiguo);

            if (nodo != null)
            {
                Jugadores jugadorNuevo = new Jugadores(
                    textBox1.Text,
                    Convert.ToInt32(textBox2.Text),
                    Convert.ToInt32(textBox3.Text),
                    textBox4.Text,
                    textBox5.Text,
                    textBox6.Text,
                    textBox7.Text,
                    textBox8.Text,
                    Convert.ToInt32(textBox9.Text),
                    Convert.ToInt32(textBox10.Text),
                    Convert.ToInt32(textBox11.Text),
                    textBox12.Text
                );

                nodo.Dato = jugadorNuevo;

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                MessageBox.Show("Jugador actualizado correctamente.");
            }
            else
            {
                MessageBox.Show("El jugador no se encontró en la lista.");
            }
        }
    }
}
