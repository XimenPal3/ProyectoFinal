﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFArbolBinario.ListaEnlazada;

//Nombre: Ximena Lissett Palencia Palacios
//Carnet: 0900-22-6072

namespace WFArbolBinario
{
    public partial class Form5 : Form
    {
        ArbolAVL ArbolAVL = new ArbolAVL();
        Lista milista = new Lista();

        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            int counter = 0;
            string line;

            System.IO.StreamReader file =
                new System.IO.StreamReader("C:\\Users\\ximen\\OneDrive\\Documents\\PremierLeague18_19_Equipos.csv");

            Char delimiter = ',';

            while ((line = file.ReadLine()) != null)
            {
                String[] substrings = line.Split(delimiter);
                Equipos objetoequipos = new Equipos(substrings[0], substrings[1], substrings[2], substrings[3],
                    Convert.ToInt32(substrings[4]), Convert.ToInt32(substrings[5]), Convert.ToInt32(substrings[6]),
                    Convert.ToInt32(substrings[7]), Convert.ToInt32(substrings[8]));

                ArbolAVL.insertar(objetoequipos);
            }
            file.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MostrarEquiposEnListBox();
        }

        private void MostrarEquiposEnListBox()
        {
            listBox1.Items.Clear();

            // Recorrer el árbol AVL y agregar los equipos a la lista enlazada
            RecorrerArbolYAgregarALista(ArbolAVL.raizArbol());

            // Recorrer la lista enlazada y mostrar los equipos en el listBox
            NodoLista nodoActual = milista.primero;
            while (nodoActual != null)
            {
                listBox1.Items.Add(((Equipos)nodoActual.Dato).ToString());
                nodoActual = nodoActual.Enlace;
            }
        }

        private void RecorrerArbolYAgregarALista(Nodo raiz)
        {
            if (raiz != null)
            {
                RecorrerArbolYAgregarALista(raiz.subarbolIzdo());
                milista.InsertarCabezaLista(raiz.valorNodo());
                RecorrerArbolYAgregarALista(raiz.subarbolDcho());
            }
        }
    }
}
